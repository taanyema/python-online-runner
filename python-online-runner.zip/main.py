from flask import Flask, request, render_template, jsonify
import os

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev_secret")  # sécurité

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/run", methods=["POST"])
def run_code():
    data = request.get_json()
    code = data.get("code", "")

    if len(code) > 5000:
        return jsonify({"output": "❌ Code trop long"})

    forbidden = ["import os", "import sys", "subprocess", "open(", "eval", "exec"]
    for f in forbidden:
        if f in code:
            return jsonify({"output": "❌ Code interdit pour des raisons de sécurité."})

    try:
        local_vars = {}
        exec(code, {}, local_vars)
        output = "\n".join(str(v) for v in local_vars.values())
    except Exception as e:
        output = f"❌ Erreur : {e}"

    return jsonify({"output": output})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 10000))
    app.run(host="0.0.0.0", port=port)